from flask import *
from flask_mysqldb import *
import librosa
import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.models import load_model

app = Flask(__name__)
app.secret_key = "speech emotion recognization"
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '1234'
app.config['MYSQL_DB'] = 'speech_emotion_recognization'
mysql = MySQL(app)
print(mysql)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/signup')
def signup():
    return render_template('signup.html')


@app.route('/insertvalues',methods=['post'])
def insertvalues():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    # used to execute queries

    uname = request.form['username']
    pwd = request.form['password']
    email = request.form['email']
    
    
    cursor.execute("insert into signup values(%s,%s,%s)",
                   (uname,email,pwd))
    mysql.connection.commit() #save changes
    return 'insert success. Please login again by going back to login page'

@app.route('/loginvalidation',methods=['post'])
def loginvalidation():
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    # used to execute queries
    user=request.form['username']
    pwd=request.form['password']
    cursor.execute("select * from signup where username=%s and password=%s",
                   (user,pwd,))
    if(cursor.fetchone()):
        return render_template("upload.html")
    else:
        return 'login fail'
    
@app.route('/submit',methods=['post'])
def submit():
    if request.method == 'POST':
        audio_path = request.files['wavfile']
        
        img_path = "static/tests/" + audio_path.filename	
        audio_path.save(img_path)
        
        predict_result =  ANN_print_prediction(img_path)

    return render_template("prediction.html", prediction = predict_result, audio_path= img_path)

def extract_feature(audio_path):
    audio_data, sample_rate = librosa.load(audio_path, res_type="kaiser_fast")
    feature = librosa.feature.mfcc(y=audio_data, sr=sample_rate, n_mfcc=40)
    feature_scaled = np.mean(feature.T, axis=0)
    return np.array([feature_scaled])


def ANN_print_prediction(audio_path):
    prediction_feature = extract_feature(audio_path)
    predicted_vector = np.argmax(Model1_ANN.predict(prediction_feature), axis=-1)
    predicted_class = le.inverse_transform(predicted_vector)
    return predicted_class[0]

final = pd.read_pickle("extracted_df.pkl")
y = np.array(final["Emotions"].tolist())
le = LabelEncoder()
le.fit_transform(y)
Model1_ANN = load_model("Model1.h5")

@app.route('/performance')
def performance():
    return render_template('performance.html')

if(__name__ == '__main__'):
    app.run(debug=True)